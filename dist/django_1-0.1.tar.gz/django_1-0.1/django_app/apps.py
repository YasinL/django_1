from django.apps import AppConfig


class DjangoAppConfig(AppConfig):
    name = 'django_app'
